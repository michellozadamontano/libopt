<h2 style="margin-top:0px">Nuevas_tareas Read</h2>
        <table class="table">
	    <tr><td>Users Id</td><td><?php echo $users_id; ?></td></tr>
	    <tr><td>Nuevatarea</td><td><?php echo $nuevatarea; ?></td></tr>
	    <tr><td>Qui&eacute;n Origin&oacute;</td><td><?php echo $quien_origino; ?></td></tr>
	    <tr><td>Causas</td><td><?php echo $causas; ?></td></tr>
	    <tr><td>Fecha</td><td><?php echo $fecha; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('nuevas_tareas') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>