<h2 style="margin-top:0px">Predefinida_fecha Read</h2>
        <table class="table">
	    <tr><td>Tarea</td><td><?php echo $tarea; ?></td></tr>
	    <tr><td>D&iacute;a</td><td><?php echo $dia; ?></td></tr>
	    <tr><td>Hora</td><td><?php echo $hora; ?></td></tr>
	    <tr><td>Users Id</td><td><?php echo $users_id; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('predefinida_fecha') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>