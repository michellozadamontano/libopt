<h2 style="margin-top:0px">Cargos Read</h2>
        <table class="table">
	    <tr><td>Nombre Cargo</td><td><?php echo $nombre_cargo; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('cargos') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>