<h2 style="margin-top:0px">Analisis Read</h2>
        <table class="table">
	    <tr><td>Users Id</td><td><?php echo $users_id; ?></td></tr>
	    <tr><td>Mes</td><td><?php echo $mes; ?></td></tr>
	    <tr><td>Ano</td><td><?php echo $ano; ?></td></tr>
	    <tr><td>Analisis</td><td><?php echo $analisis; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('analisis') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>