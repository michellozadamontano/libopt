<h2 style="margin-top:0px">Vacaciones Read</h2>
        <table class="table">
	    <tr><td>Users Id</td><td><?php echo $users_id; ?></td></tr>
	    <tr><td>Desde</td><td><?php echo $desde; ?></td></tr>
	    <tr><td>Hasta</td><td><?php echo $hasta; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('vacaciones') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>