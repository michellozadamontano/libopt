<h2 style="margin-top:0px">Actividades Read</h2>
        <table class="table">
	    <tr><td>Grupo Id</td><td><?php echo $grupo_id; ?></td></tr>
	    <tr><td>Nombre Actividad</td><td><?php echo $nombre_actividad; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('actividades') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>