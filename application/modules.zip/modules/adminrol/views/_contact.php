<div class="container">
    <div class="row">
        <div class="col-md-6 col-sm-6 col-md-offset-3">
            <div class="media">
                <div class="pull-left">
                    <div class="thumbnail">
                        <img class="media-object" src="<?php echo base_url('images/michel.jpg')?>" alt="michel">
                    </div>

                </div>
                <div class="media-body">
                    <h4> Msc.Michel Lozada Montano</h4>
                    <h5><b>Trabajador por cuenta propia.</b></h5>
                    <h6>Programador de equipos de c&oacute;mputo</h6>
                    <h6>email: <em>michellm@libodevelop.com</em></h6>
                    <h6>email: <em>michellm@nauta.cu</em></h6>
                    <h6>www: <em><a href="http://libodevelop.com">www.libodevelop.com</a></em></h6>
                    <h6>Tel: <em>+53 53846151</em></h6>
                </div>
            </div>
        </div>
    </div>
</div>
