<h2 style="margin-top:0px">Rol Read</h2>
        <table class="table">
	    <tr><td>Rol</td><td><?php echo $rol; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('adminrol') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>