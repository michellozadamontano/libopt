 <!-- BEGIN FOOTER -->
        <div class="page-footer">
            <div class="page-footer-inner">Desarrollado por:
                <a href="<?php echo base_url('adminrol/about')?>">Ing. Michel Lozada Montano</a>
                <?php
                    $date = getdate(time());
                ?>
                <span>2016 - <?php echo $date['year'] ?></span>
            </div>
            <div class="scroll-to-top">
                <i class="icon-arrow-up"></i>
            </div>
        </div>
        <!-- END FOOTER -->