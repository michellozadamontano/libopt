<h2 style="margin-top:0px">Aprobacionpt Read</h2>
        <table class="table">
	    <tr><td>Users Id</td><td><?php echo $users_id; ?></td></tr>
	    <tr><td>Fecha</td><td><?php echo $fecha; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('aprobacionpt') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>