<h2 style="margin-top:0px">Tareasprincipales Read</h2>
        <table class="table">
	    <tr><td>Users Id</td><td><?php echo $users_id; ?></td></tr>
	    <tr><td>Tarea</td><td><?php echo $tarea; ?></td></tr>
	    <tr><td>Mes</td><td><?php echo $mes; ?></td></tr>
	    <tr><td>Ano</td><td><?php echo $ano; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('tareasprincipales') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>