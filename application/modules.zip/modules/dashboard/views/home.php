<?php if (!defined('BASEPATH')) exit('No direct script access allowed');?>

<h2>Administration Panel</h2>

<p>Administration area</p>





