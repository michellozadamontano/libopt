<h2 style="margin-top:0px">Predate Read</h2>
        <table class="table">
	    <tr><td>User Id</td><td><?php echo $user_id; ?></td></tr>
	    <tr><td>Fecha</td><td><?php echo $fecha; ?></td></tr>
	    <tr><td>Hora Inicio</td><td><?php echo $hora_inicio; ?></td></tr>
	    <tr><td>Hora Fin</td><td><?php echo $hora_fin; ?></td></tr>
	    <tr><td>Actividad</td><td><?php echo $actividad; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('predate') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>